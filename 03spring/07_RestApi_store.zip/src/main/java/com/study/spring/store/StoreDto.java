package com.study.spring.store;

import lombok.Data;
import lombok.Getter;

@Data
public class StoreDto {
	Long id;
	String name;
	String addr;
}
